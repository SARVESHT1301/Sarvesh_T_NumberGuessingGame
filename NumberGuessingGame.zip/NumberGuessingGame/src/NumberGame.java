import java.util.Scanner;
import java.util.Random;

public class NumberGame {
    public static void main (String [] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        int score = 0;
        
        System.out.println("Welcome to the Number Guessing Game Buddy !");
        
        boolean playAgain = true;
        while(playAgain) {
            int randomnum = rand.nextInt(100)+1;
            int attempts = 10;
            boolean guessedCorrectly = false;
            
            System.out.println("\nI have selected a number between 1 to 100. You have " + attempts + "attempts to guess!");
            
            System.out.println(+randomnum);
            
            for(int i=1;i <= attempts;i++) {
                System.out.println("\nEnter your guesses (" +i + "/" + attempts + "): ");
                int userguess = sc.nextInt();
                if(userguess == randomnum) {
                    System.out.println("\nCorrect! You guessed it in " + i + " attempts.");
                    guessedCorrectly = true;
                    score++;
                    break;
            }else if(userguess < randomnum) {
                if(randomnum - userguess <= 5) {
                    System.out.println("Low ! but you're closer.");
                }else {
                    System.out.println("Too low ! Think again");
                }
            }else {
                if(userguess - randomnum <= 5) {
                        System.out.println("High ! but you're closer.");
                    }else {
                        System.out.println("Too high ! Think again");
                    }
                }
                
            //    System.out.println("Too low! Think again");
            //}else {
            //    System.out.println("Too high! Think again");
            //}
            
        }
        if(!guessedCorrectly) {
            System.out.println("Out of attempts! The number was: " + randomnum);
        }
        System.out.println("\nGame Over! \n\nYour total score is = " +score);
        System.out.println("\nDo you want to play again ?(y/n)");
        String answer = sc.next();
        playAgain = answer.equalsIgnoreCase("y");
    }
    sc.close();
    }
}
